"""Stat Check application package."""
